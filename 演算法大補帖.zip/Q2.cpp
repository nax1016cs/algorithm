#include<iostream>
using namespace std;
typedef long long ll;
ll n, count = 0;
ll pos= -1;
void recur(string &s){
	pos++;
	if(pos==s.size())
		return;
	if(s[pos]-'0' == 1){
		count = count + (n*n);
	}

	else if(s[pos]-'0' == 2){
		n/=2;
		for(int i=0; i<4 ; i++){
			recur(s);
		}
		n*=2;
	}
	return;
}
int main(){
	ios_base::sync_with_stdio(false);

	cin.tie(NULL);
	string s;
	cin >> n;
	cin >> s;
	recur(s);
		
	cout << count << '\n';

}