#include<iostream>
#include<unordered_map>

using namespace std;
int a[1502], b[1502], c[1502], d[1502];
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	unordered_map<long long , int> m;
	int len;
	long long target, count = 0;
	cin >> len >> target;
	for(int i=1; i<=len; i++)
		cin >> a[i];
	for(int i=1; i<=len; i++)
		cin >> b[i];
	for(int i=1; i<=len; i++)
		cin >> c[i];
	for(int i=1; i<=len; i++)
		cin >> d[i];

	for(int k=len; k>0; k--){
		for(int l=k+1; l<=len; l++){
			long long n = c[k]+d[l];
			m[n]++;

		}
		int j = k-1;
		for(int i=1; i<j; i++){
			count+=m[target-(a[i]+b[j])];
		}
	}
	cout << count << '\n';

	

}