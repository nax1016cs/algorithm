#include<iostream>
#include<queue>

using namespace std;
int main(){
	long long d, n, w;
	priority_queue<long long, std::vector<long long>, std::greater<long long> > p;
	cin >> n;
	for(long long i=0; i<n; i++){
		cin >> w;
		p.push(w);
	}
	while(p.size()>1){
		long long x = p.top();
		p.pop();
		long long y = p.top();
		p.pop();
		long long z = (x+y)*2;
		p.push(z);
	}
	cout << p.top() << '\n';
}