#include<iostream>
using namespace std;
int main(){
	long long n, a[1000010], maxx=-1111111111, sum=0;
	cin >> n;
	for(int i=0; i<n; i++){
		cin >> a[i];

	}
	int x = 1, y;
	int tmp = 1;
	for(int i=0; i<n; i++){

		
		if(a[i]>0 && sum<0){	
			sum = 0;
			tmp = i+1;	
		}
		else if(a[i]<0){
			if(a[i]>maxx){
				maxx = a[i];
				x = i+1;
				y = i+1;
			}
		}
		sum+=a[i];
		if(sum>maxx){
			maxx = sum;
			x = tmp;
			y = i+1;
		}
		
	}

	// cout << maxx << '\n';
	cout << x << ' '<< y << '\n';

}