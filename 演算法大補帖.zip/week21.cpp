#include<iostream>
#include<string.h>
#include<queue>
using namespace std;

typedef long long Graph[105][105];  // adjacency matrix
Graph C, F, R;  // 容量上限、流量、剩餘容量
bool visit[1000]; // BFS經過的點
long long path[1000];   // BFS tree
long long flow[1000];   // 源點到各點的流量瓶頸
long long n;
 
long long BFS(long long s, long long t)   // 源點與匯點
{
    memset(visit, false, sizeof(visit));
 
    queue<long long> Q;   // BFS queue
    visit[s] = true;
    path[s] = s;
    flow[s] = 1e13;
    Q.push(s);
 
    while (!Q.empty())
    {

        long long i = Q.front(); Q.pop();
        for (long long j=0; j<n + 2; ++j)
            // 剩餘網路找擴充路徑
            if (!visit[j] && R[i][j] > 0)
            {
                visit[j] = true;
                path[j] = i;
                // 一邊找最短路徑，一邊計算流量瓶頸。
                flow[j] = min(flow[i], R[i][j]);
                Q.push(j);
 
                if (j == t) return flow[t];
            }
    }
    return 0;   // 找不到擴充路徑了，流量為零。
}
 
long long Edmonds_Karp(long long s, long long t)
{
    memset(F, 0, sizeof(F));
    memcpy(R, C, sizeof(C));
 
    long long f, df;  // 最大流的流量、擴充路徑的流量
    for (f=0; df=BFS(s, t); f+=df)
        // 更新擴充路徑上每一條邊的流量
        for (long long i=path[t], j=t; i!=j; i=path[j=i])
        {
            F[i][j] = F[i][j] + df;
            F[j][i] = -F[i][j];
            R[i][j] = C[i][j] - F[i][j];
            R[j][i] = C[j][i] - F[j][i];
        }
    return f;
}
int main(){
	long long m;
	long long count = 0;
	long long w[1003];
	memset(C, 0, sizeof(C));
	cin >> n >> m;
	for(long long i=1; i<=n; i++){
		cin >> w[i];
		if(w[i]>0){
			count+=w[i];
			C[0][i] = w[i];
		}
		else{
			C[i][n+1] = -(w[i]);
		}
	}
	for(long long i=0, x, y; i<m; i++){
		cin >> x >> y;
		C[x][y] = 1e13;
	}
	long long ans = Edmonds_Karp(0, n+1);
	cout << count-ans << '\n';
}