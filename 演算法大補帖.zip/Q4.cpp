#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	
	int n, M, S;
	int block[30005];
	int sum_ = 0;
	cin >> n >> M >> S;
	for(int i=0; i<n; i++){
		cin >> block[i];
		sum_+=block[i];
	}
	int remain = M- sum_;
	S-=remain;
	if(S<=0){
		cout << 0 << '\n';
		return 0;
	}

	int dp[sum_+100];
	memset(dp, 0, sizeof(dp));
	for(int i=0; i<n; i++){
		for(int j=sum_; j>0; j--){
			if(j>=block[i])
				dp[j] = max(dp[j], dp[j-block[i]]+block[i]);
		}
	}
	int tp = S;
	for(;tp<=sum_;tp++){
		if(dp[tp]>=S){
			cout << dp[tp] << '\n';
			break;
		}
	}

}